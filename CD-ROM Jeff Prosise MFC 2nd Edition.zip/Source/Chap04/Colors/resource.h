//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Colors.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_COLORSTYPE                  129
#define IDR_CONTEXTMENU                 130
#define ID_SHAPE_CIRCLE                 32771
#define ID_SHAPE_TRIANGLE               32772
#define ID_SHAPE_SQUARE                 32773
#define ID_COLOR_RED                    32774
#define ID_COLOR_YELLOW                 32775
#define ID_COLOR_GREEN                  32776
#define ID_COLOR_CYAN                   32777
#define ID_COLOR_BLUE                   32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
